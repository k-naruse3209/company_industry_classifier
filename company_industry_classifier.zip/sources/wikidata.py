
import asyncio
from typing import Dict, Any, Optional, List, Tuple
import aiohttp
from tenacity import retry, stop_after_attempt, wait_exponential_jitter

WIKIDATA_API = "https://www.wikidata.org/w/api.php"

headers = {
    "User-Agent": "CompanyIndustryClassifier/1.0 (contact: example@example.com)"
}

@retry(stop=stop_after_attempt(3), wait=wait_exponential_jitter(1, 3))
async def wbsearch(session: aiohttp.ClientSession, name: str, lang: str="ja", limit: int=5) -> List[Dict[str, Any]]:
    params = {
        "action": "wbsearchentities",
        "search": name,
        "language": lang,
        "format": "json",
        "type": "item",
        "limit": str(limit),
    }
    async with session.get(WIKIDATA_API, params=params, headers=headers, timeout=30) as resp:
        resp.raise_for_status()
        data = await resp.json()
        return data.get("search", [])

@retry(stop=stop_after_attempt(3), wait=wait_exponential_jitter(1, 3))
async def wbgetentities(session: aiohttp.ClientSession, qids: List[str], lang: str="ja") -> Dict[str, Any]:
    params = {
        "action": "wbgetentities",
        "ids": "|".join(qids),
        "props": "labels|descriptions|claims|sitelinks",
        "languages": lang,
        "format": "json"
    }
    async with session.get(WIKIDATA_API, params=params, headers=headers, timeout=30) as resp:
        resp.raise_for_status()
        return await resp.json()

def extract_p452_claims(entity: Dict[str, Any]) -> List[str]:
    claims = entity.get("claims", {})
    p452 = claims.get("P452", [])
    vals = []
    for c in p452:
        mainsnak = c.get("mainsnak", {})
        datav = mainsnak.get("datavalue", {})
        if datav and datav.get("type") == "wikibase-entityid":
            qid = datav["value"].get("id")
            if qid:
                vals.append(qid)
    return vals

def get_label(entity: Dict[str, Any], lang: str="ja") -> Optional[str]:
    labels = entity.get("labels", {})
    return labels.get(lang, {}).get("value")

def get_description(entity: Dict[str, Any], lang: str="ja") -> Optional[str]:
    desc = entity.get("descriptions", {})
    return desc.get(lang, {}).get("value")

def get_sitelink_title(entity: Dict[str, Any], site: str="jawiki") -> Optional[str]:
    sitelinks = entity.get("sitelinks", {})
    sl = sitelinks.get(site) or sitelinks.get("enwiki")
    if sl:
        return sl.get("title")
    return None

def get_official_website(entity: Dict[str, Any]) -> Optional[str]:
    claims = entity.get("claims", {})
    p856 = claims.get("P856", [])
    for c in p856:
        mainsnak = c.get("mainsnak", {})
        datav = mainsnak.get("datavalue", {})
        if datav and datav.get("type") == "string":
            return datav["value"]
    return None
