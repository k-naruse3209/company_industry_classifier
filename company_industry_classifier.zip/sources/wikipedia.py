
import asyncio
from typing import Optional, Dict, Any
import aiohttp
from tenacity import retry, stop_after_attempt, wait_exponential_jitter

REST_BASE = "https://{lang}.wikipedia.org/api/rest_v1"

headers = {
    "User-Agent": "CompanyIndustryClassifier/1.0 (contact: example@example.com)"
}

@retry(stop=stop_after_attempt(3), wait=wait_exponential_jitter(1, 3))
async def get_summary(session: aiohttp.ClientSession, title: str, lang: str="ja") -> Optional[Dict[str, Any]]:
    url = REST_BASE.format(lang=lang) + f"/page/summary/{title}"
    async with session.get(url, headers=headers, timeout=30) as resp:
        if resp.status == 404:
            return None
        resp.raise_for_status()
        return await resp.json()
